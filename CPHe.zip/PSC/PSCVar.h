﻿#pragma once
enum BasePSCVarType {
	varInt,
	varFloat,
	varList,
	varDict,
	varStr,
	varRef,
	varFunc

};
class PSCVar {
	BasePSCVarType type;
public:
	bool operator ==(PSCVar other) {
		return (other.type == this->type);
	}
};