﻿#include"PSCBase.h"
#include"qregularexpression.h"

RegExpFactory::RegExpFactory()
{
}
void PSC_PCB::LoadCodeLines(QVector<QString>)
{
	
}

