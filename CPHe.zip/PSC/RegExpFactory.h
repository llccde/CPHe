﻿#pragma once
#include<qstring.h>
#include<qvector.h>
class RegExpFactory {
public:
	struct expItem {
		QString name;
		QString exp;
	};
	QVector<expItem> groups;
	RegExpFactory();
	int addGroup(QString groupName, QString exp) {
		groups.append({ groupName,exp });
	}
	QString toRegExp() {
		const QString itemTemplate = "(?<%1>%2)";
		QString exp = "";
		for (int i = 0; i < groups.size(); i++) {
			if (i != 0) exp.append("|");
			exp.append(QString(itemTemplate)
				.arg(groups[i].name))
				.arg(groups[i].exp);
		}
		return QString("(%1)").arg(exp);
	}

};