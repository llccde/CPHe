﻿#pragma once
#include"qstring.h"
#include"qvector.h"
#include"RegExpFactory.h"
class PSC_PCB {
public:
	
	PSC_PCB() {
		
	};
	QVector<QString> tokens;
	unsigned long long codePointer = 0;
	void LoadCodeLines(QVector<QString>);
};
class PSCInterpreter {
public:
	PSC_PCB pcb;
	RegExpFactory regFactory;
	PSCInterpreter() {
		regFactory.addGroup("indent", "[a-zA-Z_][a-zA-Z1-9]*");
	};
};