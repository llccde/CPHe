﻿#include "gui/CPHeMain.h"
#include <QtWidgets/QApplication>
#include "code/CodeAnalyzer.h"
#include"gui/NameMapView.h"
// libclang 头文件
#include <clang-c/Index.h>
#include <iostream>
#include<qfile.h>
#include<qmessagebox.h>
#include<qlist.h>
#include<qvector.h>
#include<vector>
#include"code/CodeFileReader.h"
#include"code/CppCodeFileReader.h"
#include"libClangContext.h"
#include"NameTree.h"
#include"CppCodeVisitor.h"
#include"QFileReader.h"
#include"MainClass.h"
#include"PSC/PSCVar.h"
int main(int argc, char* argv[])
{
	QRegularExpression reg(R"(?<indent>[a-zA-Z_][a-zA-Z0-9]*)(?)");
	std::cout << reg.isValid();
	std::cout << reg.captureCount();
	auto match = reg.match("void");
	if (match.hasMatch()) {
		QString matched = match.captured(0);

	}



    //QApplication app(argc, argv);
    //MainClass mainClass;
    //mainClass.showAll();

    return 0;//app.exec();
}