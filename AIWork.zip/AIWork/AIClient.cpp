﻿// AIClient.cpp
#include"LLMClient.h"

namespace awf {

    AIClient::AIClient() : m_llmType(gpt) {}

    void AIClient::setBase(const QString& url,
        const QString& key,
        const QString& model,
        LLM type)
    {
        m_baseUrl = url;
        m_apiKey = key;
        m_model = model;
        m_llmType = type;
    }

    void AIClient::set_deepSeek_thinking(bool thinking)
    {
        m_thinking = thinking;
    }

    // ---------------------------------------------------------------------------
    // 公共接口
    // ---------------------------------------------------------------------------
    QVector<QString> AIClient::getGen(QVector<ChatMessage> promot)
    {
        if (m_llmType == gemini) {
            return callGemini(promot);
        }
        else {
            // gpt / deepSeek 都走 OpenAI 兼容接口
            return callOpenAICompatible(promot);
        }
    }

    // ---------------------------------------------------------------------------
    // OpenAI / DeepSeek 兼容 API
    // ---------------------------------------------------------------------------
    QVector<QString> AIClient::callOpenAICompatible(const QVector<ChatMessage>& messages)
    {
        QVector<QString> results;

        // 拼接完整 URL：base + "/v1/chat/completions"
        QString urlStr = m_baseUrl;
        if (!urlStr.endsWith(QLatin1Char('/')))
            urlStr += QLatin1Char('/');
        urlStr += QStringLiteral("v1/chat/completions");

        QUrl url(urlStr);
        QNetworkRequest request(url);
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
        request.setRawHeader("Authorization", ("Bearer " + m_apiKey).toUtf8());

        // 构造 messages 数组
        QJsonArray jsonMessages;
        for (const auto& msg : messages) {
            QJsonObject obj;
            switch (msg.role) {
            case user:      obj["role"] = "user";      break;
            case system:    obj["role"] = "system";    break;
            case assistant: obj["role"] = "assistant"; break;
            }
            obj["content"] = msg.message;
            jsonMessages.append(obj);
        }

        QJsonObject body;
        body["model"] = m_model;
        body["messages"] = jsonMessages;
        // 要求返回多个候选（n=1 也可返回 QVector，默认 1 即可）
        body["n"] = 1;

        // DeepSeek 思考模式
        if (m_llmType == deepSeek && m_thinking) {
            QJsonObject thinking;
            thinking["type"] = "enabled";
            body["thinking"] = thinking;
        }

        QByteArray postData = QJsonDocument(body).toJson(QJsonDocument::Compact);

        QNetworkReply* reply = m_nam.post(request, postData);

        // 同步等待
        QEventLoop loop;
        QObject::connect(reply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
        loop.exec();

        if (reply->error() != QNetworkReply::NoError) {
            // 错误处理：这里简单返回空
            reply->deleteLater();
            return results;
        }

        QByteArray responseData = reply->readAll();
        reply->deleteLater();

        QJsonDocument doc = QJsonDocument::fromJson(responseData);
        if (doc.isNull() || !doc.isObject())
            return results;

        QJsonObject root = doc.object();
        QJsonArray choices = root["choices"].toArray();
        for (const QJsonValue& choiceVal : choices) {
            QJsonObject choice = choiceVal.toObject();
            QString content = choice["message"].toObject()["content"].toString();
            results.append(content);
        }

        return results;
    }

    // ---------------------------------------------------------------------------
    // Gemini API（generateContent）
    // ---------------------------------------------------------------------------
    QVector<QString> AIClient::callGemini(const QVector<ChatMessage>& messages)
    {
        QVector<QString> results;

        // URL: https://generativelanguage.googleapis.com/v1/models/{model}:generateContent?key={key}
        // 如果用户传入的 m_baseUrl 已经包含完整路径，也可以直接拼接 model 和 key
        QString urlStr = m_baseUrl;
        if (!urlStr.endsWith(QLatin1Char('/')))
            urlStr += QLatin1Char('/');
        urlStr += m_model + QStringLiteral(":generateContent?key=") + m_apiKey;

        QUrl url(urlStr);
        QNetworkRequest request(url);
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

        // Gemini 的 contents 格式：每个内容是一个 part，role 可选为 "user" / "model"
        QJsonArray contents;
        for (const auto& msg : messages) {
            QJsonObject contentObj;
            // 将 system 消息转为 user 消息（Gemini 无 system 角色，可用 user + 特殊前缀）
            QJsonArray parts;
            QJsonObject partObj;
            if (msg.role == system) {
                partObj["text"] = QStringLiteral("System: ") + msg.message;
            }
            else {
                partObj["text"] = msg.message;
            }
            parts.append(partObj);
            contentObj["parts"] = parts;

            if (msg.role == assistant) {
                contentObj["role"] = QStringLiteral("model");
            }
            else {
                contentObj["role"] = QStringLiteral("user");
            }
            contents.append(contentObj);
        }

        QJsonObject body;
        body["contents"] = contents;
        // 可设置 generationConfig，这里忽略
        QByteArray postData = QJsonDocument(body).toJson(QJsonDocument::Compact);

        QNetworkReply* reply = m_nam.post(request, postData);

        QEventLoop loop;
        QObject::connect(reply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
        loop.exec();

        if (reply->error() != QNetworkReply::NoError) {
            reply->deleteLater();
            return results;
        }

        QByteArray responseData = reply->readAll();
        reply->deleteLater();

        QJsonDocument doc = QJsonDocument::fromJson(responseData);
        if (doc.isNull() || !doc.isObject())
            return results;

        QJsonObject root = doc.object();
        QJsonArray candidates = root["candidates"].toArray();
        for (const QJsonValue& candVal : candidates) {
            QJsonObject cand = candVal.toObject();
            QJsonArray parts = cand["content"].toObject()["parts"].toArray();
            for (const QJsonValue& partVal : parts) {
                QString text = partVal.toObject()["text"].toString();
                if (!text.isEmpty())
                    results.append(text);
            }
        }

        return results;
    }

} // namespace awf