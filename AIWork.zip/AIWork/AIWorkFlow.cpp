﻿#include"LLMClient.h"
using namespace awf;
void AIWorkFlow::replaceWithFileBufferAndBackup(const QString& filePath, const QString& outPath)
{
    QString absSrcPath = getAbsPath(filePath);
    qDebug() << "源文件路径:" << absSrcPath;
    qDebug().noquote() << "准备写入的内容：\n" << fileBuffer;

    // 确定最终写入的目标路径
    QString targetPath;
    bool useBackupMode = false;   // 是否使用备份模式（覆盖原文件并备份）

    if (outPath.isEmpty() || getAbsPath(outPath) == absSrcPath) {
        // 没有指定输出文件，或输出文件就是原文件本身 → 使用备份模式
        targetPath = absSrcPath;
        useBackupMode = true;
    }
    else {
        // 指定了不同的输出文件 → 直接写入，不备份
        targetPath = getAbsPath(outPath);
        useBackupMode = false;
    }

    // ---- 备份模式处理 ----
    if (useBackupMode) {
        // 若原文件存在则创建 .bak 备份；若不存在则无需备份（直接写入即可）
        if (QFile::exists(absSrcPath)) {
            QString backupPath = absSrcPath + ".bak";
            if (!QFile::copy(absSrcPath, backupPath)) {
                riseError("无法创建备份文件：" + backupPath);
                return;
            }
            qDebug() << "已创建备份:" << backupPath;
        }
        else {
            qDebug() << "源文件不存在，跳过备份，将直接创建新文件:" << absSrcPath;
        }
    }

    // ---- 写入内容到目标文件 ----
    // 确保目标文件所在目录存在（仅当输出路径与原路径不同时，可能目录未创建）
    QFileInfo targetInfo(targetPath);
    QDir targetDir = targetInfo.absoluteDir();
    if (!targetDir.exists()) {
        if (!targetDir.mkpath(".")) {
            riseError("无法创建目标文件所在目录：" + targetDir.absolutePath());
            return;
        }
    }

    QFile file(targetPath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
        riseError("无法打开目标文件写入：" + targetPath);
        return;
    }

    QTextStream out(&file);
    out << fileBuffer;
    file.close();

    qDebug() << "成功写入文件:" << targetPath;
    // 可在此添加文件大小校验等扩展逻辑
}