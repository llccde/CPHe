﻿#pragma once
#include<qstring.h>
#include<qobject.h>
#include<qstring.h>
#include<clang-c/Index.h>
#include<functional>
#include<qmap.h>
#include<qhash.h>
#include<set>
#include<qdebug.h>
#include<qdir.h>
#include<qmetaenum>
#include<qobject.h>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QEventLoop>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
//ai work flow
namespace awf {
	struct LineInfo {
		bool isCommentOnly = false;
		QString commentText;
		QString rawLine;
		bool hasMutiLineCommentBegin = false;   // 该行是某个多行注释的起始行（/*）
		bool hasMutiLineCommentEnd = false;   // 该行是某个多行注释的结束行（*/）Z
	};
	class  M_OperatorTypeClass :public QObject {
		Q_OBJECT
	public:
		enum M_OperatorTypeInner {
			fill, ref, end,
			normalComment,
			msg,//is comment,but not begin with @,or begin with @msg
			notCommand,//原始代码文本,非注释,非指令标记
			genBegin, genEnd, debugger
		};
		Q_ENUM(M_OperatorTypeInner);
	};
	using M_OperatorType = M_OperatorTypeClass::M_OperatorTypeInner;
	using MP = M_OperatorTypeClass::M_OperatorTypeInner;
	//todo 解析设置注释起止,也可能没必要
	enum CommentState {
		singleLine,
		isBegin,
		isEnd
	};
	class M_Command {
	public:
		M_OperatorType type;
		QMap<QString, QString> args;//@op,arg1=xx,arg2=xx
		const QString& getArg(const QString& key);//有则返回,无则返回空值;
		QString arg;//@op arg
		//mean @fill{.....@end
		bool isLongOperator = false;
		QString toString() const;
		CommentState commentState;
		bool hasMutiLineCommentBegin = false; 
		bool hasMutiLineCommentEnd = false;  
	};
	QString operatorTypeToString(M_OperatorType type);
	class ClangTool {
	public:
		QVector<LineInfo> analyzeFile(const QString& filePath);
		QString getAllTheFile(const QString& p);
		void FormatTab(QVector<QString>& code, const QString refObj);
		QString clearSingleLineBreak(const QString& code);
		void clearLineBreak(QVector<QString>& code);
		QString SameTab(const QString& ori, const QString& ref);
		
	};

	class Interpreter {
	public:
		void riseWarning(const QString& wrn) {
			qDebug() << "\033[33m" << "warning:" << wrn<< "\033[0m";
		}
		void loadFile(QString filePath);
		/*is注释行(row)->bool{
			return (行不包含任何非注释代码(row))
		}
		if(is注释行(row)){
			if(注释内容以@开头(row)){
				if(结构为 "@op ?argData"){
					return{type=op}
				}if(结构为 "@op{" ){
					return{type=op,islongop=true}
				}if(结构为 "@op,arg1=s1,argx=sx"){
					return {type = op,args = {arg1=s1,argx=sx}}
				}
			}else{
				return {type = normalComment,arg=注释内容(row)}
			}
		}else{
			return {type = notCommand,arg=行内容(row)}
		}*/
		M_Command getCommandOf(int row);
		bool isCommandComment(int row);
		QString getSource(int row);
		int rowCount();

	private:
		QVector<LineInfo> mLines;
		mutable QHash<int, M_Command> mCommandCache; // 缓存解析结果

		M_OperatorType parseOperator(const QString& opStr);
		void parseArguments(const QString& argPart, QMap<QString, QString>& args);
	};
	enum Role {
		user,
		system,
		assistant      // 拼写修正：assintent -> assistant
	};

	struct ChatMessage {
		Role role;
		QString message;
	};

	class AIClient {
	public:
		enum LLM { deepSeek, gemini, gpt };

		AIClient();

		void setBase(const QString& url,
			const QString& key,
			const QString& model,
			LLM type);

		void set_deepSeek_thinking(bool thinking);

		// 参数名保留原样 promot
		QVector<QString> getGen(QVector<ChatMessage> promopt);

	private:
		QString m_baseUrl;
		QString m_apiKey;
		QString m_model;
		LLM m_llmType;
		bool m_thinking = false;   // deepseek 思考模式

		QNetworkAccessManager m_nam;

		QVector<QString> callOpenAICompatible(const QVector<ChatMessage>& messages);
		QVector<QString> callGemini(const QVector<ChatMessage>& messages);
	};
	class AIWorkFlow;
}

class awf::AIWorkFlow{
public:
	Interpreter fileProcesser;
	ClangTool tool;
	AIClient aic;
	QString workingFolder = "";
	bool inCommentBlock = false;
	QString getAbsPath(const QString& path) {
		return QDir(workingFolder).absoluteFilePath(path);
	}
	AIWorkFlow(const QString& working) :workingFolder(working) {};
	//被指向意味着已经被消费,初始没有任何符号被消费,所以为-1;
	int index = -1;
	int genId = 0;
	QString readKey(QString key = "key.txt") {
		QFile f(getAbsPath(key));
		if (f.exists() && !f.atEnd()) {
			QString s(f.readLine());
			if (s.endsWith("\n"))s.chop(1);
			return s;
		}
		riseError(getAbsPath(key) + " not found");
		return "";
	}
	QString getGenId() {
		return QString::number(genId++);
	}
	int getCurrentIndex() { return index; };
	M_Command getCurrentCommand() {
		return fileProcesser.getCommandOf(index);
	};
	QString currentSource() {
		return fileProcesser.getSource(index);
	};
	M_Command peekNext() {
		return fileProcesser.getCommandOf(index + 1);
	};
	void next(bool write = true) {
		index++;
		if(write)writeFile(fileProcesser.getSource(index));//每次取指令,固定将该行写入缓存
		auto c = getCurrentCommand();
		if (c.hasMutiLineCommentEnd) inCommentBlock = false;
		if (c.hasMutiLineCommentBegin) inCommentBlock = true;
	};
	bool hasNext() {
		return index+1 < fileProcesser.rowCount();
	};

	QString fileBuffer = "";
	void replaceWithFileBufferAndBackup(const QString& filePath, const QString& outPath);

	void writeFile(const QString& data,int index = -1) { 
		auto clean = tool.clearSingleLineBreak(data);
		if (index != -1&& index < fileProcesser.rowCount()) {
			auto data_f = tool.SameTab(clean, fileProcesser.getSource(index));
			fileBuffer.append(data_f+"\n");
			return;
		}

		fileBuffer.append(clean+"\n");
	};
	
	void writeComment(const QString& data, int index = -1) {
		if (!inCommentBlock)
		{
			writeFile("//" + data, index);
		}
		else
		{
			writeFile(data, index);
		}
	}
	void writeComment(const QVector<QString> data, int index = -1) {
		if (!inCommentBlock) {
			auto dataC = data;
			tool.clearLineBreak(dataC);
			if (index != -1 && index < fileProcesser.rowCount()) {
				tool.FormatTab(dataC, fileProcesser.getSource(index));
			}
			fileBuffer.append("/*" + dataC.join("\n") + "*/\n");
		}
		else
		{
			writeFile(data, index);
		}
	}
	void writeSource(const QString& data, int index = -1) {
		writeSource({ data },index);
	}
	void writeSource(const QVector<QString> data, int index = -1) {
		if (inCommentBlock) {
			auto dataC = data;
			dataC.push_front("*/");
			dataC.push_back("/*");
			tool.clearLineBreak(dataC);
			if (index != -1 && index < fileProcesser.rowCount()) {
				tool.FormatTab(dataC, fileProcesser.getSource(index));
			}
			fileBuffer.append(dataC.join("\n")+'\n');
		}
		else
		{
			writeFile(data, index);
		}
	}
	void writeFile(const QVector<QString>& data,int index = -1) {
		auto dataC = data;
		tool.clearLineBreak(dataC);
		if (index != -1 && index < fileProcesser.rowCount()) {
			tool.FormatTab(dataC, fileProcesser.getSource(index));
		}
		fileBuffer.append(dataC.join("\n")+"\n");
	};
	QVector<QString>errs;
	QVector<QString> wrns;
	void riseWarn(const QString& wrn) { wrns.append(wrn); };
	void riseError(const QString& err) { errs.append(err);};
	bool hasError() { return !errs.isEmpty();};
	void writeCurrentSource() {
		writeFile(fileProcesser.getSource(index));
	}
	M_Command justNextCommand() {
		next();
		return getCurrentCommand();
	}
	M_Command skipNextCommand() {
		next(false);
		return getCurrentCommand();
	};
	void newFileCommand() {
		while (true)
		{
			if (!hasNext()) {
				return;
			}
			if (hasError()) {
				return;
			}
			switch (peekNext().type)
			{
			case MP::notCommand:case MP::normalComment:
				justNextCommand();
				break;
			case MP::fill: {
				fillCommand();
				break;
			}
			case MP::genBegin:
				handleGenLable();
				break;
			case MP::genEnd: {
				riseError("未匹配的 @genEnd 标签");
				return;
			}
			case MP::debugger:{
				debugger();
				break;
			}
			default:
				riseWarn("不支持 其他指令标记 在 文档根节点下");
				justNextCommand();
				break;
			}

		}

	}
	void debugger() {
		auto current = getCurrentCommand();
		next();
		auto next = peekNext();
		return;
	}
	//todo 实现复用
	void handleGenLable() {
		next();
		auto _this = getCurrentCommand();
		bool findEnd = false;
		while (true)
		{
			if (!hasNext()) {
				riseError("文件结尾处未闭合的 @genBegin 指令标记");
				return;
				break;
			}
			auto next = peekNext();
			switch (next.type)
			{
			case MP::genBegin: {

				if (next.getArg("id") == _this.getArg("id")) {
					riseError("非预期匹配的 @genBegin 指令标记");
					return;
				}
				skipNextCommand();
				break;
			}
			case MP::genEnd: {
				if (next.getArg("id") == _this.getArg("id")) {
					findEnd = true;
				}
				skipNextCommand();
				break;
			}
			default:
				skipNextCommand();
				break;
			}
			if (findEnd) {
				break;
			}
		}
	}
	void fillCommand() {
		
		//writeFile("//@genTask,op=fill,id=" + genID, row);
		next();
		int row = getCurrentIndex();
		auto genID = getGenId();
		QString promot;
		auto cur = getCurrentCommand();
		promot.append(cur.arg);
		if (cur.isLongOperator) {
			bool findEnd = false;
			while (!findEnd)
			{
				if (!hasNext()) {
					riseError("文件结尾处未闭合的 长指令标记");
					return;
					break;
				}
				switch (peekNext().type) {
				case MP::ref: {
					auto ref = justNextCommand();
					promot.append(tool.getAllTheFile(getAbsPath(ref.arg)));
					break;
				}
				case MP::msg: case MP::normalComment:{
					auto text = justNextCommand();
					promot.append(text.arg);
					break;
				}
				case MP::end:
					findEnd = true;
					justNextCommand();
					break;
				default:
					riseWarn("在@fill 长指令标记 区间内,除去@ref,@end,不支持任何其他指令");
					justNextCommand();
					break;
				}
			}
		}
		writeComment("@genBegin,op=fill,id=" + genID,row);
		writeSource(aic.getGen({ {user,promot} }), row);
		writeComment("@genEnd,id="+genID,row);
	}

	void launch(const QString& filePath, const QString& outPath) {
		fileProcesser.loadFile(getAbsPath(filePath));
		aic.setBase("https://api.deepseek.com",readKey(),"deepseek-v4-pro",AIClient::deepSeek);
		aic.set_deepSeek_thinking(true);
		newFileCommand();
		
		if (!hasError())
			replaceWithFileBufferAndBackup(getAbsPath(filePath),getAbsPath(outPath));
		else
		{
			qDebug()<< "\033[31m"<<"error";
			qDebug().noquote() << errs.join("\n") << "\033[0m";
		}
	}
};

